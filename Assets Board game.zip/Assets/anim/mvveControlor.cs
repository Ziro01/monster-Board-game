﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mvveControlor : MonoBehaviour
{
    private Rigidbody rb;
    public bool moveLeft;
    public bool moveRight;
    
    public bool moveUp;
    public bool moveDown;

    public float horizontalMove;
    public float VerticalMove;
    public float speed;
    private void Start() {
        rb = GetComponent<Rigidbody>();
    }
    void Update(){
        if (Input.GetKey("a")){
            moveLeft = true;
            print("a");
        }
        else{
            moveLeft = false;
        }

        if (Input.GetKey("d")){
            moveRight = true;
            print("d");
        }
        else{
            moveRight = false;
        }

        if (Input.GetKey("w")){
            moveUp = true;
            print("w");
        }
        else{
            moveUp = false;
        }

        if (Input.GetKey("s")){
            moveDown = true;
            print("s");
        }
        else{
            moveDown = false;
        }
       
        MovementPlayer();
    }
 
    //Now let's add the code for moving
    private void MovementPlayer(){
        //If i press the left button
        if (moveLeft){
            horizontalMove = speed;
            VerticalMove = 0;
            // transform.position += new Vector3(speed,0,0);

            //  transform.Translate(horizontalMove,0f,0f);
        }
 
        //if i press the right button
        else if (moveRight){
            horizontalMove =- speed;
            VerticalMove = 0;
            // transform.position -= new Vector3(speed,0,0);
            // transform.Translate(horizontalMove,0f,0f);
        }
        
        else if (moveUp) {
            VerticalMove =- speed;
            horizontalMove =- 0;
            // transform.position += new Vector3(0,speed,0);
            // transform.Translate(0f,0f,VerticalMove);
            
        }
 
        //if i press the right button
        else if (moveDown){
            VerticalMove = speed;
            horizontalMove = 0;
            // transform.position -= new Vector3(0,speed,0);
            // transform.Translate(0f,0f,VerticalMove);
            
        }
        //if i am not pressing any button
        else {
            horizontalMove = 0;
            VerticalMove = 0;
            // transform.position -= new Vector3(0,0,0);
            // transform.Translate(0f,0f,0f);
        }
    }
 
    //add the movement force to the player
    private void FixedUpdate()
    {
        // MovementPlayer();
        // rb.velocity = new Vector3(horizontalMove, rb.velocity.y, rb.velocity.z);
        // print( "rb : "+rb.velocity);
        rb.velocity = new Vector3(horizontalMove,0f,VerticalMove);

        // transform.Translate(horizontalMove,0f,VerticalMove);
    }
}
