﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class display_channel : MonoBehaviour
{
    public Text txt_Box;
    public SpriteRenderer sprite_Box;
}
