using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class car_Move : MonoBehaviour
{
    public float speed;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void moveCar(){
        movespeed++;
        transform.position.x  = transform.position.x + movespeed;
    }
}
