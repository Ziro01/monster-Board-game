﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class managerChannel : MonoBehaviour
{
    // public float speed;
    [System.Serializable]
    public class data_channel{
        public Transform channels;
        public int gotoBox;
    }
    public List<data_channel> manager_channel = new List<data_channel>();

    public Sprite[] Box_img;

    void Start(){
        for (int i = 0; i < manager_channel.Count ; i++) {
            int number = i;
            string box_number = number.ToString(); 
            manager_channel[i].channels.gameObject.GetComponent<display_channel>().txt_Box.text = box_number.ToString();
            setSprite(i);
        }
    }

    void setSprite(int _number){
        int idBox = 0;
        if((_number % 2) == 0) idBox = 1;

        manager_channel[_number].channels.gameObject.GetComponent<display_channel>().sprite_Box.sprite = Box_img[idBox];
    }
    void Update() {}
}
