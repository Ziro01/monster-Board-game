using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class managerUIgame : MonoBehaviour
{
    public Text  txt_countTime;
    public Text  txt_yourWalk;
    public Text  txt_yourTime;
    public GameObject popUp;
}