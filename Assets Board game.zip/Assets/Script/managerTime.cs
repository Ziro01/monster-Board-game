﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// using UnityEngine.UI;

public class managerTime : MonoBehaviour
{
    // public Text  txt_countTime;
    // public Text  txt_countWalk;
    bool runTime;
    public float countTime = 0f;
    void Start()
    {
        
    }


    void Update(){
        if(runTime == true)countTime += Time.deltaTime;
    }

    public void resetTime(){
        countTime = 0f;
        runTime = true;
    }

    public void runTimeing(){
        runTime = true;
    }

    public void stopTime(){
        runTime = false;
    }






    public string disPlayTime(float _time){ 
        string t;
        float min = Mathf.FloorToInt(_time / 60);
        float sec = Mathf.FloorToInt(_time % 60);
        
        t = string.Format("{0:00}:{1:00}",min,sec);
        return t;
    }
}
