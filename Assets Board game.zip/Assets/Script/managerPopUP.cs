﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class managerPopUP : MonoBehaviour
{
    public Text txt_youTime;
    public Text txt_youWalk;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
