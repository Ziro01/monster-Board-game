﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class randomNumber : MonoBehaviour
{
    public managerPlayer player_1;
    public Text txt_number;
    public int number;
    // public int set_number;
    public bool iSReady;
    
    void Start()
    {
        player_1 = FindObjectOfType<managerPlayer>();
    }

    void Update(){ }

    public void enter_to_Box(int toBox){
        player_1.goBox(toBox);
    }

    public void Bnt_random(){
        if(iSReady == true){
            number = Random_number();

            // if(set_number == number) number = Random_number();

            txt_number.text = number.ToString();
            player_1.enter_numberBox(number);
            iSReady = false;
            // set_number =  number;
            FindObjectOfType<managerrGame_All>().yourWalk++;
        }
    } 

    public static int Random_number(){
        int number_;
        number_ = Random.Range(1,6);
        return number_;
    }
}
