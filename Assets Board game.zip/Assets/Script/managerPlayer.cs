﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class managerPlayer : MonoBehaviour
{
    // public managerChannel fromChannel;
    public int channel_new;
    public int countBox;
    public int boxIng;
    private Rigidbody2D rb;
    public bool ready;
    public managerChannel Main_channel;
    public float speed;
    public int numberBox;
    // public List<Transform> boxNumber = new List<Transform>();

    void Start() {
        rb = GetComponent<Rigidbody2D>();
        Main_channel = FindObjectOfType<managerChannel>();
    }

    void Update() {
        if(ready == true){
            run();
        } 
        else{
            Check_Box();
        }
    }

    public void enter_numberBox(int _inbex){
        if(_inbex > 0){
            countBox = _inbex;
            ready = true;
        }
    }

    void Check_Box(){
        int toBox = Main_channel.manager_channel[channel_new].gotoBox;
        if(toBox != 0) goBox(toBox);
    }
    public void run(){  
        if(transform.position != Main_channel.manager_channel[channel_new].channels.position) {
            Vector2 box = Vector2.MoveTowards(transform.position,Main_channel.manager_channel[channel_new].channels.position,speed*Time.deltaTime);
            rb.MovePosition(box);
        } 
        else{
            // print("2");
            channel_new = (channel_new + 1)% Main_channel.manager_channel.Count;

            if(countBox -1 > 0){  //count to box
                countBox -= 1;
                print("count : " + countBox);
            }
            else{
                ready = false;
                FindObjectOfType<randomNumber>().iSReady = true;
                if(channel_new == 0){
                    boxIng = Main_channel.manager_channel.Count;
                }
                else{
                    boxIng = (channel_new -1);
                }
            }

            if(channel_new == 0){
                ready = false;
               FindObjectOfType<managerrGame_All>().overGame(); 
            } 
        }
    }

    public void goBox(int _boxNumber){
        if(_boxNumber < Main_channel.manager_channel.Count ) channel_new = _boxNumber;

        ready = true;
    }

    public void reBox(){
        transform.position = Main_channel.manager_channel[0].channels.position;

        ready = true;
    }
}
