﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class special_box : MonoBehaviour
{
    public int BoxCount;
    void Start()
    {
        BoxCount = gameObject.GetComponent<managerChannel>().manager_channel.Count;
    }
    void Update()
    {
        
    }
}
