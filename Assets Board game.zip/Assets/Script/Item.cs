﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    public int id_Item;
    public int n_Item;
    // public TextMesh txt_n;

    //  public float gan_X;
    // public float gan_y;
    // public float gan_Z;
    void Start(){
        // txt_n.text = n_Item +" Kg".ToString();
    }

    // Update is called once per frame
    void Update(){
        // gan_X = transform.position.x;
        // gan_y = transform.position.y;
        // gan_Z = transform.position.z;
    }
}
