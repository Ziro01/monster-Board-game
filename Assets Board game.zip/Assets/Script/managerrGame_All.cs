﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class managerrGame_All : MonoBehaviour
{
    public int yourWalk;
    public bool gameing;
    string _time;
    void Start()
    {
        FindObjectOfType<managerUIgame>().txt_countTime.text = "00:00";
    }

    private void FixedUpdate() {
        if(gameing == true){
            float countTimes = FindObjectOfType<managerTime>().countTime;
            _time = FindObjectOfType<managerTime>().disPlayTime(countTimes).ToString();
            FindObjectOfType<managerUIgame>().txt_countTime.text = _time;
        }
    }

    public void startGame(){
        FindObjectOfType<managerUIgame>().popUp.gameObject.SetActive(false);
        FindObjectOfType<managerTime>().resetTime();

        FindObjectOfType<randomNumber>().txt_number.text = "run";
        FindObjectOfType<randomNumber>().iSReady = true;

        FindObjectOfType<managerPlayer>().countBox = 0;
        FindObjectOfType<managerPlayer>().reBox();

        yourWalk = 0;
        gameing = true;
        
    }

    public void overGame(){
        gameing = false;
        FindObjectOfType<managerTime>().stopTime();
        FindObjectOfType<managerUIgame>().popUp.gameObject.SetActive(true);
        FindObjectOfType<managerUIgame>().txt_yourWalk.text = "your Walk : " + yourWalk.ToString();
        FindObjectOfType<managerUIgame>().txt_yourTime.text = "your Time : " + _time.ToString();

        
    }
}
