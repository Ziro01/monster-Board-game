﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Route : MonoBehaviour
{
    Transform[] childObj;
    public List<Transform> childList = new List<Transform>();

    private void OnDrawGizmos() {
        Gizmos.color = Color.green;
    }

    void fillNodes(){
        childList.Clear();
        childObj = GetComponentsInChildren<Transform>();

        foreach (var child in childObj){
            if(child != this.transform) childList.Add(child);
        }
    }
    void Start()
    {
        
    }

    
    void Update()
    {
        
    }
}
