using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stane : MonoBehaviour
{
    public Route c_Route;
    int routePos;

    public int steps;
    public bool isMoving;

    int nextPos;
    
    void Start()
    {
        
    }
    void Update()
    {
        
    }

    public void click(int _nextPos){
        nextPos = _nextPos;
        StartCoroutine(Move());
        print(c_Route.childList[_nextPos].transform.position); 
    }

    IEnumerator Move(){
        if(isMoving) yield break;

        isMoving = true;

        // while(steps > 0){
        //     Vector3 nextPos = c_Route.childList[routePos + 1].position;

            while(MoveToNext_Pos(nextPos)){
                yield return null;
            }

            yield return new WaitForSeconds(0.1f);
            // steps--;
            // routePos++;
        // }
        
        
        

        isMoving = false;
    }

    // bool MoveToNext_Pos(Vector3 goal){
    //     return goal != (transform.position = Vector3.MoveTowards(transform.position,c_Route[],2f * Time.deltaTime));
    //     // transform.position = Vector3.MoveTowards(transform.position,goal,2f * Time.deltaTime);
    // }

    bool MoveToNext_Pos(int goal){
        Vector3 getPos = c_Route.childList[goal].transform.position;
        // print("getPos : "+getPos);
        return getPos != (transform.position = Vector3.MoveTowards(transform.position,getPos,2f * Time.deltaTime));
        // transform.position = Vector3.MoveTowards(transform.position,goal,2f * Time.deltaTime);
    }
}
