﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotation : MonoBehaviour
{
    public Transform target;
 
    void Update () {
        //change as needed (here rotate around y axis)
        Vector3 rotationAxis = Vector3.up; 

        //project direction to target -> into the rotation plane 
        Vector3 projDirToTarget = Vector3.ProjectOnPlane (target.position - transform.position, rotationAxis);

        //get the rotation for looking into the projected direction
        Quaternion newRotation = Quaternion.LookRotation (projDirToTarget, rotationAxis);

        //animate rotation of character to the new rotation
        transform.rotation = Quaternion.Slerp (transform.rotation, newRotation,2f* Time.deltaTime);
    }
}
