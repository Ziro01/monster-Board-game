﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class joyController : MonoBehaviour
{
        // [Space(15)]
        public int Left;
        public int Right;
        public int UP;
        public int Down;
    

    // public managerChannel Main_channel;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void to_Left(){
        int n = FindObjectOfType<Player>().Posing;
        int id = FindObjectOfType<Player>().c_managerRoute.manager_channel[n].Left;
        print( "to_Left : "+id);
        
        FindObjectOfType<Player>().click(id);
    }
    public void to_Right(){
        int n = FindObjectOfType<Player>().Posing;
        int id = FindObjectOfType<Player>().c_managerRoute.manager_channel[n].Right;
        print( "to_Right : "+id);
        FindObjectOfType<Player>().click(id);
    }
    public void to_UP(){
        int n = FindObjectOfType<Player>().Posing;
        int id = FindObjectOfType<Player>().c_managerRoute.manager_channel[n].UP;
        print( "to_UP : "+id);
    }
    public void to_Down(){
        int n = FindObjectOfType<Player>().Posing;
        int id = FindObjectOfType<Player>().c_managerRoute.manager_channel[n].Down;
        print( "to_Down : "+id);
        FindObjectOfType<Player>().click(id);
    }
}
