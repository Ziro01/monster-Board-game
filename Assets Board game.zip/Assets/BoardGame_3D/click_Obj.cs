﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class click_Obj : MonoBehaviour
{
    public int id;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnMouseDown() {
        print(gameObject.name +":id  " + id);
        // FindObjectOfType<Stane>().click(id);
        FindObjectOfType<Player>().click(id);

    }
}
