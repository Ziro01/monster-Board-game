﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class createItem : MonoBehaviour
{
    public  GameObject prefab_item_1;
    public  GameObject prefab_item_2;
    public managerRoute c_managerRoute;
    void Start()
    {
        
    }
    public int min,max;
    public int number;
    public List<int> pointId = new List<int>();
    public List<int> pointIdexist = new List<int>();
    public List<int> pointIdRandom = new List<int>();
    public void reset_Point(){
        pointId.Clear();
        pointIdRandom.Clear();

        for (int i = min; i < max; i++){
            pointId.Add(i+1);
        }
    }
    public  void random_Point_count(int _count){
        for(int i = 0; i < _count; i++){
            if(pointId.Count > 1){
                number = random_number(min,pointId.Count);
                remote_Point(number);
                print("number : " + pointId[number]);
            }
        }
    }

    public  void random_Point(){
        if(pointId.Count > 1){
            number = random_number(min,pointId.Count);
            remote_Point(number);
            print("number : " + pointId[number]);
        }
    }
    
    void remote_Point(int _p){
        pointIdexist.Clear();
        for (int i = 0; i < pointId.Count; i++){
            if(pointId[i] != pointId[_p]){

                pointIdexist.Add(pointId[i]);
            }
            else{
                print( "i: "+i+" number : " + pointId[i]);
                pointIdRandom.Add(pointId[i]);
                create_Item(pointId[i]);
            }
        }

        pointId.Clear();
        foreach (var item in pointIdexist) {
            pointId.Add(item);
        }
    }

    int random_number(int _min,int _max){
        int n = Random.Range(_min,_max-1);
        return n;
    } 
    public void create_Item(int _pos){

        bool Boolean = Random.Range(0, 2) != 0;
            Debug.Log(Boolean);
        
        if(Boolean == true){
            GameObject item_1 = Instantiate(prefab_item_1, c_managerRoute.manager_channel[_pos].channels.position, c_managerRoute.manager_channel[_pos].channels.rotation);
            item_1.GetComponent<Item>().id_Item = 1;
            item_1.GetComponent<Item>().n_Item = random_number(3,10);
        }
        else{
            GameObject item_2 = Instantiate(prefab_item_2, c_managerRoute.manager_channel[_pos].channels.position, c_managerRoute.manager_channel[_pos].channels.rotation);
            item_2.GetComponent<Item>().id_Item = 2;
            item_2.GetComponent<Item>().n_Item = random_number(3,10);
        }
        
    }
}
