﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Random_item : MonoBehaviour
{
    public int min,max;
    public int number;
    public List<int> pointId = new List<int>();
    public List<int> pointIdexist = new List<int>();
    public List<int> pointIdRandom = new List<int>();
    // Start is called before the first frame update
    
    void Start()
    {
        
    }
    public void reset_Point(){
        pointId.Clear();
        pointIdRandom.Clear();

        for (int i = min; i < max; i++){
            pointId.Add(i+1);
        }
    }
    public  void random_Point_count(int _count){
        for(int i = 0; i < _count; i++){
            if(pointId.Count > 1){
                number = random_number(min,pointId.Count);
                remote_Point(number);
                print("number : " + pointId[number]);
            }
        }
        
    }

    public  void random_Point(){
        if(pointId.Count > 1){
            number = random_number(min,pointId.Count);
            remote_Point(number);
            print("number : " + pointId[number]);
        }
    }
    
    void remote_Point(int _p){
        pointIdexist.Clear();
        for (int i = 0; i < pointId.Count; i++){
            if(pointId[i] != pointId[_p]){

                pointIdexist.Add(pointId[i]);
            }
            else{
                print( "i: "+i+" number : " + pointId[i]);
                pointIdRandom.Add(pointId[i]);
            }
        }

        pointId.Clear();
        foreach (var item in pointIdexist)
        {
            pointId.Add(item);
        }
    }


    int random_number(int _min,int _max){
        int n = Random.Range(_min,_max-1);
        return n;
    }

    // Update is called once per frame

    public void create_Item(){

    }
    void Update()
    {
        
    }
}
