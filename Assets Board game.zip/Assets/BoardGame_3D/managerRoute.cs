﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class managerRoute : MonoBehaviour
{
    [System.Serializable]
    public class data_channel{
        public Transform channels;
        public int item_id;
        public int weight;
        [Space(15)]
        public int Left;
        public int Right;
        public int UP;
        public int Down;
        
    }
    public List<data_channel> manager_channel = new List<data_channel>();
}
