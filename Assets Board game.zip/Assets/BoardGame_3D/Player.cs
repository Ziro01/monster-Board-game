﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public managerRoute c_managerRoute;
    int routePos;

    public int steps;
    public bool isMoving;

    public int nextPos;
    public int Posing;
    float speed = 3f;
    Quaternion playerRot;
    void Start(){}
    void Update(){}
    public void click(int _nextPos){
        if( _nextPos ==  c_managerRoute.manager_channel[Posing].Left || _nextPos ==  c_managerRoute.manager_channel[Posing].Right || _nextPos ==  c_managerRoute.manager_channel[Posing].UP || _nextPos ==  c_managerRoute.manager_channel[Posing].Down)
        {
            if(!isMoving){
                nextPos = _nextPos;
                StartCoroutine(Move());
                // print(c_managerRoute.manager_channel[_nextPos].channels.transform.position); 
                Vector3 getRot = c_managerRoute.manager_channel[nextPos].channels.transform.position;
            }
        }
    }
    // void check(int _pos){
    //     //_pos ค่ามาเช็ค
    //     if( _pos ==  c_managerRoute.manager_channel[Posing].Left || _pos ==  c_managerRoute.manager_channel[Posing].Right || _pos ==  c_managerRoute.manager_channel[Posing].UP || _pos ==  c_managerRoute.manager_channel[Posing].Down)
    //     {
    //       click(_pos);  
    //     }
    // }
    IEnumerator Move(){
        if(isMoving) yield break;

        isMoving = true;
        // 
        // while(steps > 0){
        //     Vector3 nextPos = c_managerRoute.childList[routePos + 1].position;

            while(MoveToNext_Pos(nextPos)){
                MoveToNext_Rot(nextPos);
                yield return null;
            }
            
           
            

            yield return new WaitForSeconds(0.1f);
            // steps--;
            // routePos++;
        // }

        isMoving = false;
        Posing = nextPos;
    }

    // bool MoveToNext_Pos(Vector3 goal){
    //     return goal != (transform.position = Vector3.MoveTowards(transform.position,c_managerRoute[],2f * Time.deltaTime));
    //     // transform.position = Vector3.MoveTowards(transform.position,goal,2f * Time.deltaTime);
    // }

    bool MoveToNext_Pos(int goal){
        Vector3 getPos = c_managerRoute.manager_channel[goal].channels.transform.position;
        Vector3 setPos = new Vector3(getPos.x,5f,getPos.z);
        

        // print("getPos : "+getPos);
        return setPos != (transform.position = Vector3.MoveTowards(transform.position,setPos,speed * Time.deltaTime));
        // transform.position = Vector3.MoveTowards(transform.position,goal,2f * Time.deltaTime);
    }

    void MoveToNext_Rot(int goal){
        //change as needed (here rotate around y axis)
        Vector3 rotationAxis = Vector3.up; 

        //project direction to target -> into the rotation plane 
        Vector3 projDirToTarget = Vector3.ProjectOnPlane (c_managerRoute.manager_channel[goal].channels.position - transform.position, rotationAxis);

        //get the rotation for looking into the projected direction
        Quaternion newRotation = Quaternion.LookRotation (projDirToTarget, rotationAxis);

        //animate rotation of character to the new rotation
        transform.rotation = Quaternion.Slerp (transform.rotation, newRotation,5f* Time.deltaTime);
       
    }
}
